
export const LEDGER_DATA = [
    { Item: "Trailer (Model AST-200)", Category: "Asset", Cost: 32000.00, Date: "2026-01-17" },
    { Item: "3x Forno Paulistano Ovens", Category: "Equipment", Cost: 1746.42, Date: "2025-10-22" },
    { Item: "LLC Filing Fee", Category: "Legal", Cost: 500.00, Date: "2026-01-20" },
    { Item: "Flour & Yeast", Category: "Supplies (Food)", Cost: 120.00, Date: "2026-01-20" },
    { Item: "Pepperoni & Cheese", Category: "Supplies (Food)", Cost: 250.00, Date: "2026-01-21" }
];

export const SALES_DATA = [
    { "Client/Event": "Lunch Shift - Peabody", Type: "Daily Sales", Revenue: 450.00, Date: "2026-01-18" },
    { "Client/Event": "Private Birthday Party", Type: "Catering (Flat Rate)", Revenue: 1200.00, Date: "2026-01-20" }
];

export const MENU_ITEMS = [
    { "Pizza Name": "Margherita", Price: 14.00, Toppings: "Basil, Mozzarella" },
    { "Pizza Name": "Pepperoni", Price: 16.00, Toppings: "Cup Pepperoni" },
    { "Pizza Name": "Uruguayan Special", Price: 18.00, Toppings: "Beef, Spinach" }
];
