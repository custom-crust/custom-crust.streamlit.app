import { useState } from "react";
import { Sidebar, SidebarContent, SidebarHeader, SidebarProvider, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuItem, SidebarMenuButton } from "@/components/ui/sidebar";
import { StDataFrame, StMetric, StSelect } from "@/components/StreamlitWidgets";
import { LEDGER_DATA, SALES_DATA, MENU_ITEMS } from "@/lib/mock-data";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { format } from "date-fns";
import { 
  CalendarIcon, 
  LayoutDashboard, 
  Receipt, 
  ShieldCheck, 
  Pizza, 
  CircleDollarSign,
  PieChart as PieChartIcon,
  PlusCircle,
  Plus,
  Save,
  Trash2,
  Info,
  Download,
  Cloud
} from "lucide-react";
import { 
  PieChart, 
  Pie, 
  Cell, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from "recharts";
import { cn } from "@/lib/utils";

const COLORS = ['#FF4B4B', '#1f77b4', '#ff7f0e', '#2ca02c', '#9467bd', '#8c564b'];

export default function Dashboard() {
  const [menu, setMenu] = useState("Dashboard");
  const [date, setDate] = useState<Date>();
  const [localMenu, setLocalMenu] = useState(MENU_ITEMS);

  const totalExp = LEDGER_DATA.reduce((acc, curr) => acc + curr.Cost, 0);
  
  const categoryData = LEDGER_DATA.reduce((acc: any[], curr) => {
    const existing = acc.find(item => item.name === curr.Category);
    if (existing) {
      existing.value += curr.Cost;
    } else {
      acc.push({ name: curr.Category, value: curr.Cost });
    }
    return acc;
  }, []).sort((a, b) => b.value - a.value);

  const renderContent = () => {
    switch (menu) {
      case "Dashboard":
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold tracking-tight">Financial Overview</h1>
              <div className="flex items-center gap-2 text-xs font-mono text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                <Cloud className="h-3 w-3" />
                LIVE GOOGLE SYNC ACTIVE
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border-none shadow-sm bg-red-50">
                <StMetric label="Total Expenses" value={`$${totalExp.toLocaleString(undefined, { minimumFractionDigits: 2 })}`} />
              </Card>
              <Card className="border-none shadow-sm bg-blue-50">
                <StMetric label="Active Assets" value="Trailer & Ovens" />
              </Card>
              <Card className="border-none shadow-sm bg-emerald-50">
                <StMetric label="Status" value="Operational" />
              </Card>
            </div>

            <Separator />

            <Card className="border shadow-sm bg-white p-6">
              <h3 className="font-semibold text-lg mb-6 text-center">Expense Distribution (The Wheel)</h3>
              <div className="h-[400px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={80}
                      outerRadius={120}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => `$${value.toLocaleString()}`}
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                    />
                    <Legend verticalAlign="bottom" height={36}/>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>
        );

      case "Log Expenses":
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Log Business Expenses</h1>
              <p className="text-muted-foreground mt-2 font-medium italic">Saves directly to Master Ledger Spreadsheet</p>
            </div>

            <Card className="border shadow-md">
              <CardContent className="pt-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="item" className="text-xs uppercase font-bold text-muted-foreground tracking-widest">Item</Label>
                      <Input id="item" placeholder="What did you buy?" className="h-12 border-slate-300 focus:ring-primary/20" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cost" className="text-xs uppercase font-bold text-muted-foreground tracking-widest">Cost ($)</Label>
                      <Input id="cost" type="number" placeholder="0.00" className="h-12 border-slate-300 focus:ring-primary/20" />
                    </div>
                  </div>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label className="text-xs uppercase font-bold text-muted-foreground tracking-widest">Category</Label>
                      <StSelect 
                        options={["Supplies (Food)", "Asset (Trailer)", "Equipment", "Maintenance", "Marketing", "Legal"]} 
                        value="Supplies (Food)"
                        onChange={() => {}}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs uppercase font-bold text-muted-foreground tracking-widest">Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className={cn("w-full h-12 justify-start text-left font-normal border-slate-300", !date && "text-muted-foreground")}>
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date ? format(date, "PPP") : <span>Pick a date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                </div>
                <Separator />
                <Button className="bg-primary hover:bg-primary/90 text-white h-12 px-8 font-bold flex items-center gap-2" onClick={() => alert("Successfully saved to your Master Ledger (Google Sheet)!")}>
                  <Cloud className="h-5 w-5" />
                  Log to Google Sheet
                </Button>
              </CardContent>
            </Card>
          </div>
        );

      case "Sales & Catering":
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h1 className="text-3xl font-bold tracking-tight">Revenue Tracking</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Button variant="outline" className="h-32 flex flex-col gap-2 border-dashed">
                <PlusCircle className="h-6 w-6" />
                <span>Log Daily Truck Sale</span>
              </Button>
              <Button variant="outline" className="h-32 flex flex-col gap-2 border-dashed">
                <PlusCircle className="h-6 w-6" />
                <span>Log Catering Event</span>
              </Button>
            </div>
          </div>
        );

      case "Menu Management":
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold tracking-tight">Menu Management</h1>
              <Button variant="outline" size="sm" className="gap-2 bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100" onClick={() => alert("Menu updated in the cloud!")}>
                <Save className="h-4 w-4" /> Save Changes to Google Sheet
              </Button>
            </div>
            
            <Card className="border shadow-sm p-4 bg-slate-50 border-slate-200">
              <div className="flex items-center gap-3 text-sm text-slate-600">
                <Info className="h-4 w-4 text-primary" />
                <p>Edit your menu items below. Changes will sync to your Google Sheet master menu.</p>
              </div>
            </Card>

            <div className="rounded-xl border overflow-hidden shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b">
                  <tr>
                    <th className="px-6 py-4 font-bold text-xs uppercase text-slate-500 tracking-wider">Pizza Name</th>
                    <th className="px-6 py-4 font-bold text-xs uppercase text-slate-500 tracking-wider">Price ($)</th>
                    <th className="px-6 py-4 font-bold text-xs uppercase text-slate-500 tracking-wider">Toppings</th>
                    <th className="px-6 py-4 w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y bg-white">
                  {localMenu.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-medium">{item["Pizza Name"]}</td>
                      <td className="px-6 py-4 font-mono">${item.Price.toFixed(2)}</td>
                      <td className="px-6 py-4 text-slate-600 text-sm">{item.Toppings}</td>
                      <td className="px-6 py-4 text-right">
                        <Button variant="ghost" size="icon" className="text-slate-300 hover:text-red-500">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case "Vault":
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h1 className="text-3xl font-bold tracking-tight">The Vault</h1>
            <p className="text-muted-foreground font-medium italic">Secure Storage for Operations Documentation</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button variant="outline" className="h-32 flex flex-col items-center justify-center gap-3 border-dashed hover:border-primary hover:text-primary transition-all group">
                <Download className="h-8 w-8 text-muted-foreground group-hover:text-primary" />
                <div className="text-center font-bold">Business License</div>
              </Button>
              <Button variant="outline" className="h-32 flex flex-col items-center justify-center gap-3 border-dashed hover:border-primary hover:text-primary transition-all group">
                <ShieldCheck className="h-8 w-8 text-muted-foreground group-hover:text-primary" />
                <div className="text-center font-bold">Trailer Title</div>
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-slate-50/50">
        <Sidebar className="border-r bg-white">
          <SidebarHeader className="h-16 flex items-center px-6 border-b">
            <h2 className="font-bold text-lg flex items-center gap-2">
              <span className="text-2xl">🍕</span> Custom Crust
            </h2>
          </SidebarHeader>
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-2 font-mono">HQ OPERATIONAL HUB</SidebarGroupLabel>
              <SidebarMenu>
                {[
                  { name: "Dashboard", icon: LayoutDashboard },
                  { name: "Log Expenses", icon: Receipt },
                  { name: "Sales & Catering", icon: CircleDollarSign },
                  { name: "Menu Management", icon: Pizza },
                  { name: "Vault", icon: ShieldCheck },
                ].map((item) => (
                  <SidebarMenuItem key={item.name}>
                    <SidebarMenuButton 
                      onClick={() => setMenu(item.name)}
                      isActive={menu === item.name}
                      className={menu === item.name ? "bg-primary text-white hover:bg-primary hover:text-white" : "text-slate-600 hover:bg-slate-100"}
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 overflow-y-auto bg-white md:m-3 md:rounded-2xl md:border shadow-xl">
          <div className="max-w-5xl mx-auto p-8 md:p-12">
            {renderContent()}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
