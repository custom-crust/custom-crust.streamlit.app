import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

// Metric Widget
interface StMetricProps {
  label: string;
  value: string | number;
  delta?: string;
  deltaColor?: "normal" | "inverse" | "off";
}

export function StMetric({ label, value, delta, deltaColor = "normal" }: StMetricProps) {
  const isPositive = delta?.startsWith("+");
  const deltaClass = deltaColor === "off" 
    ? "text-muted-foreground"
    : (isPositive && deltaColor === "normal") || (!isPositive && deltaColor === "inverse")
      ? "text-green-600"
      : "text-red-600";

  return (
    <div className="flex flex-col space-y-1.5 p-4 rounded-lg hover:bg-muted/50 transition-colors">
      <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider text-xs">{label}</span>
      <div className="flex items-baseline space-x-2">
        <span className="text-3xl font-bold tracking-tight">{value}</span>
        {delta && (
          <span className={cn("text-sm font-medium flex items-center", deltaClass)}>
            {isPositive ? "↑" : "↓"} {delta}
          </span>
        )}
      </div>
    </div>
  );
}

// Dataframe Widget
export function StDataFrame({ data }: { data: any[] }) {
  if (!data.length) return null;
  const headers = Object.keys(data[0]);

  return (
    <div className="rounded-md border overflow-hidden my-4">
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-muted/50 text-muted-foreground font-medium">
            <tr>
              {headers.map((h) => (
                <th key={h} className="px-4 py-3 font-mono text-xs uppercase tracking-wider border-b">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y">
            {data.map((row, i) => (
              <tr key={i} className="hover:bg-muted/50 transition-colors">
                {headers.map((h) => (
                  <td key={h} className="px-4 py-2 font-mono text-xs">{row[h]}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Input Widgets
export function StSelect({ label, options, value, onChange }: any) {
  return (
    <div className="space-y-2 mb-6">
      <Label className="text-xs font-semibold uppercase text-muted-foreground">{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="bg-background border-input/80 focus:ring-primary/20">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {options.map((opt: string) => (
            <SelectItem key={opt} value={opt}>{opt}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

export function StSlider({ label, min, max, value, onChange, step = 1 }: any) {
  return (
    <div className="space-y-4 mb-6">
      <div className="flex justify-between items-center">
        <Label className="text-xs font-semibold uppercase text-muted-foreground">{label}</Label>
        <span className="font-mono text-xs text-muted-foreground">{value}</span>
      </div>
      <Slider 
        min={min} 
        max={max} 
        step={step} 
        value={[value]} 
        onValueChange={(vals) => onChange(vals[0])}
        className="[&>.absolute]:bg-primary"
      />
    </div>
  );
}

export function StToggle({ label, checked, onChange }: any) {
  return (
    <div className="flex items-center justify-between space-x-2 mb-4">
      <Label className="text-sm font-medium">{label}</Label>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
